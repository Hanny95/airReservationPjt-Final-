function cancelReservationFun(uri) {
	console.log('uri: ' + uri);
	
	if(confirm('really!!')) {
		location.href = uri;
	}
	
}