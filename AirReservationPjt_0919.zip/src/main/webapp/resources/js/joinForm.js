function joinFun() {
	console.log('joinFun() INIT!!');
	
	var joinForm = document.joinForm;
	
	if(joinForm.m_mail.value == "") {
		alert("please input mail address!!");
		joinForm.m_mail.focus();
		
	} else if(joinForm.m_pw.value == "") {
		alert("please input password!!");
		joinForm.m_pw.focus();
		
	} else {
		joinForm.submit();
		
	}
}