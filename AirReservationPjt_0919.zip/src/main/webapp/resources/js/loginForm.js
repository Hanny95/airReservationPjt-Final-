function loginFun() {
	console.log('loginFun() INIT!!');
	
	var loginForm = document.loginForm;
	
	if(loginForm.m_mail.value == "") {
		alert("please input mail address!!");
		loginForm.m_mail.focus();
		
	} else if(loginForm.m_pw.value == "") {
		alert("please input password!!");
		loginForm.m_pw.focus();
		
	} else {
		loginForm.submit();
		
	}
}



function adminLoginFun() {
	console.log('adminLoginFun() INIT!!');
	
	var loginForm = document.loginForm;
	
	if(loginForm.a_mail.value == "") {
		alert("please input admin mail address!!");
		loginForm.a_mail.focus();
		
	} else if(loginForm.a_pw.value == "") {
		alert("please input admin password!!");
		loginForm.a_pw.focus();
		
	} else {
		loginForm.submit();
		
	}
}


