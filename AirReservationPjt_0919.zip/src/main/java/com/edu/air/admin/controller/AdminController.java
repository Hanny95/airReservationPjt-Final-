package com.edu.air.admin.controller;


import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.edu.air.admin.service.AdminService;
import com.edu.air.admin.vo.AdminVo;
import com.edu.air.member.service.MemberService;
import com.edu.air.member.vo.MemberVo;
import com.edu.air.reservation.service.ReservatoinService;
import com.edu.air.reservation.vo.ReservationVo;

@Controller
@RequestMapping(value="/admin")
public class AdminController {

	@Autowired
	AdminService adminService;
	
	@Autowired
	MemberService memberService;
	
	@Autowired
	ReservatoinService reservatoinService;
	
	@RequestMapping(value = "", method = RequestMethod.GET)
	public String admin() {
		System.out.println("[AdminController] admin() INIT");
		
		return "redirect:/admin/";
	}
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String adminHome() {
		System.out.println("[AdminController] adminHome() INIT");
		
		return "admin/loginForm";
	}
	
	@RequestMapping(value = "/loginConfirm", method = RequestMethod.POST)
	public String loginConfirm(AdminVo adminVo, HttpSession session) {
		System.out.println("[AdminController] loginConfirm() INIT");
		
		int result = adminService.loginConfirm(adminVo);
		
		if (result > 0) {
			session.setAttribute("admin", adminVo.getA_mail());
			return "redirect:/admin/";
			
		} else {
			return "redirect:/admin/";
		}
		
	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session) {
		System.out.println("[AdminController] logout() INIT");
		
		session.invalidate();
		
		return "redirect:/admin/";
	}
	
	@RequestMapping(value = "/members", method = RequestMethod.GET)
	public String members(Model model) {
		System.out.println("[AdminController] members() INIT");
		
		List<MemberVo> memberVos = memberService.getMembers();
		model.addAttribute("memberVos", memberVos);
		
		return "admin/members";
	}
	
	@RequestMapping(value = "/reservations", method = RequestMethod.GET)
	public String reservations(Model model) {
		System.out.println("[AdminController] reservations() INIT");
		
		List<ReservationVo> reservationVos = reservatoinService.getReservations();
		model.addAttribute("reservationVos", reservationVos);
		
		return "admin/reservations";
	}
	
	@RequestMapping(value = "/reservationModifyForm", method = RequestMethod.GET)
	public String reservationModifyForm(@RequestParam int r_no, Model model) {
		System.out.println("[AdminController] reservationModifyForm() INIT");
		
		ReservationVo reservationVo = reservatoinService.getReservation(r_no);
		model.addAttribute("reservationVo", reservationVo);
		
		return "admin/reservationModifyForm";
	}
	
	@RequestMapping(value = "/reservationModifyConfirm", method = RequestMethod.POST)
	public String reservationModifyConfirm(ReservationVo reservationVo, Model model) {
		System.out.println("[ReservationController] reservationModifyConfirm INIT!!");
		
		int result = reservatoinService.modifyReservation(reservationVo);
		model.addAttribute("reservationVo", reservationVo);
		
		return "redirect:/admin/reservations";
	}
	
	@RequestMapping(value = "/reservationCancel", method = RequestMethod.GET)
	public String reservationCancel(@RequestParam int r_no) {
		System.out.println("[AdminController] reservationCancel() INIT");
		
		int result = reservatoinService.cancelReservation(r_no);
		
		return "redirect:/admin/reservations";
	}
	
}
