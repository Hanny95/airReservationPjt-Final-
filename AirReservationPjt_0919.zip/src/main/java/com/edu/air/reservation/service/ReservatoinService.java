package com.edu.air.reservation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.air.reservation.dao.ReservationDao;
import com.edu.air.reservation.vo.ReservationVo;

@Service
public class ReservatoinService {

	@Autowired
	ReservationDao reservationDao;
	
	public List<ReservationVo>  reservationConfirm(ReservationVo reservationVo) {
		System.out.println("[ReservatoinService] reservationConfirm() INIT!!");
		
		int result = reservationDao.insertReservation(reservationVo);
		
		List<ReservationVo> reservationVos =  null;
		if (result > 0) {
			reservationVos = reservationDao.selectReservationsByMail(reservationVo.getR_mail());
		}
		
		return reservationVos;
	}

	public List<ReservationVo> getReservations(String m_mail) {
		System.out.println("[ReservatoinService] getReservations() INIT!!");
		
		List<ReservationVo> reservationVos = 
				reservationDao.selectReservationsByMail(m_mail);
		
		return reservationVos;
	}

	public ReservationVo getReservation(int r_no) {
		System.out.println("[ReservatoinService] getReservation() INIT!!");
		
		ReservationVo reservationVo =  reservationDao.selectReservationByNo(r_no);
		
		return reservationVo;
	}

	public int modifyReservation(ReservationVo reservationVo) {
		System.out.println("[ReservatoinService] modifyReservation() INIT!!");
		
		int result = reservationDao.updateReservation(reservationVo);
		
		return result;
	}

	public int cancelReservation(int r_no) {
		
		int result = reservationDao.deleteReservation(r_no);
		
		return result;
	}

	public List<ReservationVo> getReservations() {
		
		List<ReservationVo> reservationVos = reservationDao.selectReservationsByMail();
		
		return reservationVos;
	}

}
