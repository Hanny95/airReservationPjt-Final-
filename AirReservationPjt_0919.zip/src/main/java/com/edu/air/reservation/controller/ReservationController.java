package com.edu.air.reservation.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.edu.air.reservation.service.ReservatoinService;
import com.edu.air.reservation.vo.ReservationVo;

@Controller
@RequestMapping(value = "/reservation")
public class ReservationController {

	@Autowired
	ReservatoinService reservatoinService;
	
	@RequestMapping(value = "/reservationForm", method = RequestMethod.GET)
	public String reservationForm() {
		System.out.println("[ReservationController] reservationForm INIT!!");
		
		return "reservation/reservationForm";
	}
	
	@RequestMapping(value = "/reservationConfirm", method = RequestMethod.POST)
	public String reservationConfirm(ReservationVo reservationVo, Model model) {
		System.out.println("[ReservationController] reservationConfirm INIT!!");
		
		List<ReservationVo> reservationVos = reservatoinService.reservationConfirm(reservationVo);
		
		model.addAttribute("reservationVos", reservationVos);
		
		return "reservation/reservationList";
	}
	
	@RequestMapping(value = "/reservationList", method = RequestMethod.GET)
	public String reservationList(HttpSession httpSession, Model model) {
		System.out.println("[ReservationController] reservationList INIT!!");
		
		String m_mail = String.valueOf(httpSession.getAttribute("loginMember"));
		
		List<ReservationVo> reservationVos = reservatoinService.getReservations(m_mail);
		model.addAttribute("reservationVos", reservationVos);
		
		return "reservation/reservationList";
		
	}
	
	@RequestMapping(value = "/reservationModifyForm", method = RequestMethod.GET)
	public String reservationModifyForm(@RequestParam int r_no, Model model) {
		System.out.println("[ReservationController] reservationModifyForm INIT!!");
		
		ReservationVo reservationVo = reservatoinService.getReservation(r_no);
		model.addAttribute("reservationVo", reservationVo);
		
		return "/reservation/reservationModifyForm";
		
	}
	
	@RequestMapping(value = "/reservationModifyConfirm", method = RequestMethod.POST)
	public String reservationModifyConfirm(ReservationVo reservationVo, Model model) {
		System.out.println("[ReservationController] reservationModifyConfirm INIT!!");
		
		int result = reservatoinService.modifyReservation(reservationVo);
		model.addAttribute("reservationVo", reservationVo);
		
		return "redirect:/reservation/reservationList";
		
	}
	
	@RequestMapping(value = "/reservationCancel", method = RequestMethod.GET)
	public String reservationCancel(@RequestParam int r_no, Model model) {
		System.out.println("[ReservationController] reservationCancel INIT!!");
		
		int result = reservatoinService.cancelReservation(r_no);
		
		return "redirect:/reservation/reservationList";
		
	}
	
}
