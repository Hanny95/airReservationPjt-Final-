package com.edu.air.member.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.air.member.dao.MemberDao;
import com.edu.air.member.vo.MemberVo;

@Service
public class MemberService {

	@Autowired
	MemberDao memberDao;
	
	public int joinMember(MemberVo memberVo) {
		System.out.println("[MemberService] joinMember() INIT!!");
		
		if (memberDao.isMember(memberVo)) {
			return MemberDao.MEMBER_IS;					// 1
			
		} else {
			return memberDao.insertMember(memberVo);	// 2(success) or 3(fail)
			
		}
		
	}

	public int loginConfirm(MemberVo memberVo) {
		
		int result = memberDao.loginMember(memberVo);
		
		return result;
	}

	public List<MemberVo> getMembers() {
		
		List<MemberVo> memberVos = memberDao.selectMembers();
		
		return memberVos;
	}

}
